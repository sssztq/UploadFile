package system.exception;

import java.io.IOException;

public class FileUploadException extends RuntimeException{
    public FileUploadException(IOException e) {
        super(e);
    }
}
