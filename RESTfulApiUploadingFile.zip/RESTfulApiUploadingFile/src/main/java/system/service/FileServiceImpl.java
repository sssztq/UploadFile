package system.service;

import system.entity.FileMetadata;
import system.exception.FileUploadException;
import system.repository.FileRepo;
import system.vo.FileVO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class FileServiceImpl implements FileService {

    private static final Logger LOG = LoggerFactory.getLogger(FileServiceImpl.class);

    @Autowired
    private FileRepo fileRepo;

    @Override
    @Transactional
    public FileVO saveFile(MultipartFile file, FileVO metaData) {
        FileMetadata fileData = new FileMetadata();
        LOG.info(file + " " + file.getContentType());
        fileData.setUploadTime(metaData.getUploadTime());
        fileData.setUserId(metaData.getUserId());
        fileData.setFileName(file.getOriginalFilename());
        FileMetadata savedFileData = fileRepo.save(fileData);
        metaData.setFileId(savedFileData.getId());
        metaData.setFileName(file.getOriginalFilename());
        metaData.setDocId(fileData.getDocId());
        //save to file system
        //fileDate.setDocId("/files/" + filename);
        LOG.info("File Id: " + fileData.getDocId());
        return metaData;
    }

    @Override
    @Transactional(readOnly = true)
    public List<FileVO> searchFileBy(String keyword) {
        List<FileMetadata> entityList = fileRepo.findByFileNameOrUserId(keyword);
        List<FileVO> resList = new ArrayList<>();
        for (FileMetadata data : entityList) {
            resList.add(new FileVO(data.getId(),data.getUserId(),data.getUploadTime(),data.getFileName(),data.getDocId()));
        }
        return resList;
    }
}
