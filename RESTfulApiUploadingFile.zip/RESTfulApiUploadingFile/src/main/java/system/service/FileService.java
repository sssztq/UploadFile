package system.service;

import org.springframework.web.multipart.MultipartFile;

import system.vo.FileVO;

import java.util.List;

public interface FileService {
    FileVO saveFile(MultipartFile file, FileVO metaData);

    List<FileVO> searchFileBy(String keyword);
}
