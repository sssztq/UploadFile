package system.controller;

import system.service.FileService;
import system.vo.FileVO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

@RestController
public class FileController {

    private static final Logger LOG = LoggerFactory.getLogger(FileController.class);

    @Autowired
    private FileService fileService;

    @PostMapping(value = "/upload",produces = "application/json")
    public FileVO uploadFile(@RequestParam MultipartFile file, @RequestParam String userId){
        FileVO metaData = new FileVO();
        metaData.setUploadTime(new Date());
        metaData.setUserId(userId);
        LOG.info(metaData.toString());
        return fileService.saveFile(file,metaData);
    }

    @GetMapping(value = "/file/find",produces = "application/json")
    public List<FileVO> findMeta(@RequestParam String keyword){
        LOG.info("Searching by keyword: " + keyword);
        return fileService.searchFileBy(keyword);
    }
}
